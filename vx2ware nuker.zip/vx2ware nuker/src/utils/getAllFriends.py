import time
import requests
from utils.common import *

def get_all_friends(token):
    set_console_title("VX2WAER V1 | Made by 5hk8 | Get Friends")
    headers = {"authorization": token, "user-agent": "bruh6/9"}
    r = requests.get(
        "https://canary.discord.com/api/v8/users/@me/relationships", headers=headers
    )
    print("\n")
    for friend in r.json():
        print(f"{Fore.WHITE}[ {Fore.LIGHTCYAN_EX}C {Fore.WHITE}] {friend['user']['username']}#{friend['user']['discriminator']}")
    time.sleep(2)
    print("\n")
    input("Press any key to continue...")
